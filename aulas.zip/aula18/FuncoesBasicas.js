function saudacao(nome) {
    return `Bom dia ${nome}!`;
}

const variavel = saudacao(nome);
console.log(variavel);
