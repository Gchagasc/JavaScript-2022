let num1 = prompt('Digite um número');
let num2 = prompt('Digite um número');

num1 = Number(num1);
num2 = Number(num2);

alert(`O resultado do calculo é ${num1 + num2}`);